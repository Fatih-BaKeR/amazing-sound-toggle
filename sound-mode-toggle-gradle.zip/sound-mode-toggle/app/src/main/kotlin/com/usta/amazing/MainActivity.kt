package com.usta.amazing

import android.app.Activity
import android.app.NotificationManager
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("AmazingPrefs", Context.MODE_PRIVATE)

        val rgPair = findViewById<RadioGroup>(R.id.rgPair)
        val swBip = findViewById<Switch>(R.id.swBip)
        val tvSoundHeader = findViewById<TextView>(R.id.tvSoundHeader)
        val layoutSound = findViewById<LinearLayout>(R.id.layoutSound)
        val rgSound = findViewById<RadioGroup>(R.id.rgSound)
        val btnKaydet = findViewById<Button>(R.id.btnKaydet)
        val btnHizli = findViewById<Button>(R.id.btnHizliAyarlaraEkle)
        val tvIzinDurum = findViewById<TextView>(R.id.tvIzinDurum)
        val btnIzin = findViewById<Button>(R.id.btnIzin)

        val rbDing = findViewById<RadioButton>(R.id.rbDing)
        val rbPop = findViewById<RadioButton>(R.id.rbPop)
        val rbDouble = findViewById<RadioButton>(R.id.rbDouble)
        val rbMarimba = findViewById<RadioButton>(R.id.rbMarimba)
        val rbBlip = findViewById<RadioButton>(R.id.rbBlip)

        when (prefs.getString("pair", "ALL")) {
            "NORMAL_VIBRATE" -> rgPair.check(R.id.rbNormalVibrate)
            "NORMAL_SILENT" -> rgPair.check(R.id.rbNormalSilent)
            else -> rgPair.check(R.id.rbAll)
        }
        swBip.isChecked = prefs.getBoolean("bip_enabled", false)
        when (prefs.getString("sound_type", "DING")) {
            "DING" -> rgSound.check(R.id.rbDing)
            "POP" -> rgSound.check(R.id.rbPop)
            "DOUBLE" -> rgSound.check(R.id.rbDouble)
            "MARIMBA" -> rgSound.check(R.id.rbMarimba)
            "BLIP" -> rgSound.check(R.id.rbBlip)
            else -> rgSound.check(R.id.rbDing)
        }

        tvSoundHeader.setOnClickListener {
            if (layoutSound.visibility == View.GONE) {
                layoutSound.visibility = View.VISIBLE
                tvSoundHeader.text = "Ses Seçimi ▾"
            } else {
                layoutSound.visibility = View.GONE
                tvSoundHeader.text = "Ses Seçimi ▸"
            }
        }

        rgPair.setOnCheckedChangeListener { _, id ->
            val v = when (id) {
                R.id.rbNormalVibrate -> "NORMAL_VIBRATE"
                R.id.rbNormalSilent -> "NORMAL_SILENT"
                else -> "ALL"
            }
            prefs.edit().putString("pair", v).apply()
        }

        swBip.setOnCheckedChangeListener { _, b ->
            prefs.edit().putBoolean("bip_enabled", b).apply()
        }

        rbDing.setOnClickListener {
            prefs.edit().putString("sound_type", "DING").apply()
            playPreview("DING")
        }
        rbPop.setOnClickListener {
            prefs.edit().putString("sound_type", "POP").apply()
            playPreview("POP")
        }
        rbDouble.setOnClickListener {
            prefs.edit().putString("sound_type", "DOUBLE").apply()
            playPreview("DOUBLE")
        }
        rbMarimba.setOnClickListener {
            prefs.edit().putString("sound_type", "MARIMBA").apply()
            playPreview("MARIMBA")
        }
        rbBlip.setOnClickListener {
            prefs.edit().putString("sound_type", "BLIP").apply()
            playPreview("BLIP")
        }

        btnKaydet.setOnClickListener {
            Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show()
        }

        btnIzin.setOnClickListener {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 23 && !nm.isNotificationPolicyAccessGranted) {
                try {
                    val i = Intent().apply {
                        action = "android.settings.NOTIFICATION_POLICY_ACCESS_DETAIL_SETTINGS"
                        data = Uri.parse("package:$packageName")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(i)
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
            } else {
                Toast.makeText(this, "İzin zaten verilmiş", Toast.LENGTH_SHORT).show()
            }
        }

        btnHizli.setOnClickListener { hizliAyarlaraEkle() }
        izinDurumunuGuncelle(tvIzinDurum, btnIzin)
    }

    private fun playPreview(type: String) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            when (type) {
                "POP" -> tg.startTone(ToneGenerator.TONE_PROP_BEEP, 90)
                "DOUBLE" -> {
                    tg.startTone(ToneGenerator.TONE_PROP_ACK, 100)
                    Handler(Looper.getMainLooper()).postDelayed({ tg.startTone(ToneGenerator.TONE_PROP_ACK, 100) }, 150)
                }
                "MARIMBA" -> tg.startTone(ToneGenerator.TONE_CDMA_PIP, 180)
                "BLIP" -> tg.startTone(ToneGenerator.TONE_PROP_BEEP, 70)
                else -> tg.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            }
            Handler(Looper.getMainLooper()).postDelayed({ try { tg.release() } catch (e: Exception) {} }, 500)
        } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        izinDurumunuGuncelle(findViewById(R.id.tvIzinDurum), findViewById(R.id.btnIzin))
    }

    private fun izinDurumunuGuncelle(tv: TextView, btn: Button) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val granted = if (Build.VERSION.SDK_INT >= 23) nm.isNotificationPolicyAccessGranted else true
        if (granted) {
            tv.text = "İzin verildi ✓"
            tv.setTextColor(getColor(android.R.color.holo_green_dark))
            btn.text = "İzin Verildi"
        } else {
            tv.text = "İzin verilmedi - Sessiz moda geçmek için gerekli"
            tv.setTextColor(getColor(android.R.color.holo_red_dark))
            btn.text = "İzin Ver"
        }
    }

    private fun hizliAyarlaraEkle() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            Toast.makeText(this, "Bu özellik Android 13 ve üstü gerektirir", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val sbm = getSystemService(StatusBarManager::class.java)
            sbm.requestAddTileService(
                ComponentName(this, SoundToggleTileService::class.java),
                getString(R.string.app_name),
                Icon.createWithResource(this, R.drawable.ic_volume_up),
                mainExecutor
            ) { result ->
                runOnUiThread {
                    when (result) {
                        StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED -> Toast.makeText(this, "Tile eklendi ✓", Toast.LENGTH_SHORT).show()
                        StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED -> Toast.makeText(this, "Tile zaten ekli", Toast.LENGTH_SHORT).show()
                        StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_NOT_ADDED -> Toast.makeText(this, "Tile eklenemedi", Toast.LENGTH_SHORT).show()
                        else -> Toast.makeText(this, "Tile eklenemedi", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("Amazing", "ekleme hatasi", e)
        }
    }
}