package com.usta.amazing

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager

class RingerModeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null) return
        if (intent?.action == AudioManager.RINGER_MODE_CHANGED_ACTION) {
            SoundToggleTileService.refresh(context)
        }
    }
}