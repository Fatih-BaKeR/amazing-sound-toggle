package com.usta.amazing

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings

class TileSoundSettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            startActivity(Intent(Settings.ACTION_SOUND_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            })
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
        finish()
    }
}