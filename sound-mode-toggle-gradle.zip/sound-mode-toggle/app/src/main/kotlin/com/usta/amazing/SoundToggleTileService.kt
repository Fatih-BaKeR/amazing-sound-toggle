package com.usta.amazing

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

class SoundToggleTileService : TileService() {

    companion object {
        fun refresh(context: Context) {
            try {
                requestListeningState(context, ComponentName(context, SoundToggleTileService::class.java))
            } catch (e: Exception) { }
        }
    }

    private fun getPrefs(): SharedPreferences {
        return getSharedPreferences("AmazingPrefs", Context.MODE_PRIVATE)
    }

    private fun updateTileUI(mode: Int) {
        val tile = qsTile ?: return
        when (mode) {
            AudioManager.RINGER_MODE_NORMAL -> {
                tile.label = "Sesli"
                tile.icon = Icon.createWithResource(this, R.drawable.ic_volume_up)
                tile.state = Tile.STATE_ACTIVE
            }
            AudioManager.RINGER_MODE_VIBRATE -> {
                tile.label = "Titreşim"
                tile.icon = Icon.createWithResource(this, R.drawable.ic_vibrate)
                tile.state = Tile.STATE_ACTIVE
            }
            else -> {
                tile.label = "Sessiz"
                tile.icon = Icon.createWithResource(this, R.drawable.ic_silent)
                tile.state = Tile.STATE_INACTIVE
            }
        }
        tile.updateTile()
    }

    private fun playSoftSound(type: String) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            when (type) {
                "POP" -> tg.startTone(ToneGenerator.TONE_PROP_BEEP, 90)
                "DOUBLE" -> {
                    tg.startTone(ToneGenerator.TONE_PROP_ACK, 100)
                    Handler(Looper.getMainLooper()).postDelayed({ tg.startTone(ToneGenerator.TONE_PROP_ACK, 100) }, 150)
                }
                "MARIMBA" -> tg.startTone(ToneGenerator.TONE_CDMA_PIP, 180)
                "BLIP" -> tg.startTone(ToneGenerator.TONE_PROP_BEEP, 70)
                else -> tg.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            }
            Handler(Looper.getMainLooper()).postDelayed({ try { tg.release() } catch (e: Exception) {} }, 500)
        } catch (e: Exception) { }
    }

    override fun onStartListening() {
        super.onStartListening()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            updateTileUI(am.ringerMode)
        } catch (e: Exception) { }
    }

    override fun onClick() {
        super.onClick()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 23 && !nm.isNotificationPolicyAccessGranted) {
                Toast.makeText(this, "Önce Rahatsız Etmeyin izni ver", Toast.LENGTH_SHORT).show()
                try {
                    val i = Intent().apply {
                        action = "android.settings.NOTIFICATION_POLICY_ACCESS_DETAIL_SETTINGS"
                        data = Uri.parse("package:$packageName")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivityAndCollapse(i)
                } catch (e: Exception) {
                    startActivityAndCollapse(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                }
                return
            }
            val pair = getPrefs().getString("pair", "ALL")
            val cur = am.ringerMode
            val next = when (pair) {
                "NORMAL_VIBRATE" -> if (cur == AudioManager.RINGER_MODE_NORMAL) AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL
                "NORMAL_SILENT" -> if (cur == AudioManager.RINGER_MODE_NORMAL) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_NORMAL
                else -> if (cur == AudioManager.RINGER_MODE_NORMAL) AudioManager.RINGER_MODE_VIBRATE else if (cur == AudioManager.RINGER_MODE_VIBRATE) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_NORMAL
            }
            am.ringerMode = next
            if (next == AudioManager.RINGER_MODE_NORMAL && getPrefs().getBoolean("bip_enabled", false)) {
                playSoftSound(getPrefs().getString("sound_type", "DING") ?: "DING")
            }
            updateTileUI(next)
        } catch (e: Exception) { }
    }
}